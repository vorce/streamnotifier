import streamservice
import json
import urllib2

class Justin(streamservice.StreamService):
  _JUSTIN_STREAM = 'stream'
  _JUSTIN_FORMAT = 'format'
  _stream_livestatus_prefix = 'http://api.justin.tv/api/stream/list.json?channel='
  _stream_prefix = 'http://justin.tv/'
  _service_name = 'Justin'

  def __init__(self, channel):
    self.status_url = '{0}{1}'.format(Justin._stream_livestatus_prefix, channel)
    self.service_name = Justin._service_name
    self.url = '{0}{1}'.format(Justin._stream_prefix, channel)
    self.channel = channel

  def isLive(self):
    channel_http = urllib2.urlopen(self.status_url)
    status_response = channel_http.readline()
    status_json = json.loads(status_response)
    try:
      return status_json[0].get(Justin._JUSTIN_FORMAT)
    except IndexError:
      return False

