import sys
try:
   import Growl
except ImportError:
   print("No growl available. Download bindings at http://growl.info/")
   sys.exit(-1)

import notifier
import livestream, justin, ustream, own3d

class GrowlNotifier(notifier.Notifier):
  def init(self):
    self.name = '{0} notifier'.format(self.streamservice.service_name.lower())
    self.notifications = ['Stream is up!', 'Stream is offline']
    self.notifier = Growl.GrowlNotifier(self.name, self.notifications)

    serv = self.streamservice.service_name.lower()
    if(serv == livestream.Livestream._service_name.lower()):
      self.notifier.applicationIcon = Growl.Image.imageFromPath('images/ls-icon-256x256.png')
    elif(serv == justin.Justin._service_name.lower()):
      self.notifier.applicationIcon = Growl.Image.imageFromPath('images/justintv_badge_57_57.png')
    elif(serv == ustream.Ustream._service_name.lower()):
      self.notifier.applicationIcon = Growl.Image.imageFromPath('images/Ustream_final_logo_tag_CMYK.png')
    elif(serv == own3d.Own3d._service_name.lower()):
      self.notifier.applicationIcon = Growl.Image.imageFromPath('images/own3d_logo.png')

    self.notifier.register()
    self.inited = True

  def notifyLive(self, more=''):
    if(self.inited):
      self.notifier.notify(self.notifications[0], 'The {0} stream is live'.format(self.streamservice.channel), '{0}'.format(self.streamservice.url))

  def notifyDead(self, more=''):
    if(self.inited):
      self.notifier.notify(self.notifications[1], 'The {0} stream is offline'.format(self.streamservice.channel), '{0}'.format(self.streamservice.url))

