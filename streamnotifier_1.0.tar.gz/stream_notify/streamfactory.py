import ustream, livestream, justin, own3d
import streamservice

class StreamFactory(object):
  services = {ustream.Ustream._service_name.lower():ustream.Ustream, livestream.Livestream._service_name.lower():livestream.Livestream, justin.Justin._service_name.lower():justin.Justin, own3d.Own3d._service_name.lower():own3d.Own3d}

  def __new__(klass, service, channel):
    return StreamFactory.services[service.lower()](channel)

