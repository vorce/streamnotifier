Stream notifier
---------------

Notifies you when your favorite stream channels are live.

Currently supported stream services:
* Livestream.com
* Justin.tv
* Ustream.tv
* Own3d
Planned: Xfire

Currently supported ways of notification:
* Growl (http://growl.info)
* Gmail (mail to self)
* Log (to text file)
Planned: C2DM (android), SMS

Growl notifier
--------------
Displays a short Growl notification about the stream being up or down.

Gmail notifier
--------------
E-mails yourself with a short notification about the configured stream being up. It will NOT email when a stream goes down.

Log notifier
------------
This notifier will automatically create a log file (in the same dir as where the script is run) with the filename
Service_Channel.log for the specific stream. It will be filled with lines
on the format:
YYYY-MM-DD HH:MM:SS.ssssss: Service[Channel], isLive: True|False
Example:
2010-11-12 19:25:30.225262: Livestream[TreeEskimo], isLive: True
2010-11-12 20:23:44.788831: Livestream[TreeEskimo], isLive: False

Configuration file format
-------------------------
See example.cfg

