import json
import notifier, growlnotifier
import streamfactory
import livestream, justin, ustream, own3d
import channel


class Profile:
  def __init__(self, profile=None):
    self.profile = profile

  def saveToFile(self, filename):
    fp = open(filename, 'w')
    json_out = json.dumps(channels, ident=2)
    fp.write(json_out)
    fp.close()

  def loadFromFile(self, filename):
    fp = open(filename, 'r')
    pr = fp.read()
    self.profile = json.loads(pr)
    fp.close()

  def createNotifiers(self):
    for c in self.profile[1:]:
      service = c[0]
      channelName = c[1]
      interval = int(c[2])
      nnames = c[3]
      streamserv = streamfactory.StreamFactory(service.lower(), channelName)
      nots = []

      for n in nnames:
	if(n[0].lower() == 'growl'):
	  nots.append(growlnotifier.GrowlNotifier(streamserv))
	elif(n[0].lower() == 'log'):
	  nots.append(notifier.LogNotifier(streamserv))
	elif(n[0].lower() == 'gmail'):
	  emailNotifier = notifier.GmailNotifier(streamserv)
	  emailNotifier.setCredentials(n[1], n[2])
	  nots.append(emailNotifier)
     
      for n in nots:
	n.init()

      cn = channel.ChannelNotifier(streamserv, interval, nots)
      cn.start()
    
