class StreamService:
  def __init__(self, channel):
    self.channel = channel
    self.url = ''
    self.service_name = ''
 
  def isLive(self):
    raise NotImplementedException("Subclasses are responsible for implementing this method")

  def __repr__(self):
    return '{0}:{1}:{2}'.format(self.service_name, self.channel, self.url)

