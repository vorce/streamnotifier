import profile
import sys

def printUsage():
  print('You must supply a profile/configuration file as a second argument')

if __name__ == '__main__':
  # read config
  if(len(sys.argv) < 2):
    printUsage()
    sys.exit(-1)

  profileFile = sys.argv[1]
  pr = profile.Profile()
  pr.loadFromFile(profileFile)
  pr.createNotifiers()

