# http://api.own3d.tv/liveCheck.php?live_id=214
import streamservice
import urllib2
import xml
from xml.dom import minidom

class Own3d(streamservice.StreamService):
  _stream_livestatus_prefix = 'http://api.own3d.tv/liveCheck.php?live_id='
  _stream_prefix = 'http://www.own3d.tv/live/'
  _OWN3D_STATUS_TAG = 'isLive'
  _service_name = 'Own3d'
  
  def __init__(self, channel):
    self.status_url = '{0}{1}'.format(Own3d._stream_livestatus_prefix, channel)
    self.service_name = Own3d._service_name
    self.url = '{0}{1}'.format(Own3d._stream_prefix, channel)
    self.channel = channel

  def isLive(self):
    channel_http = urllib2.urlopen(self.status_url)
    status_response = channel_http.read()

    try:
      status_xml = minidom.parseString(status_response)
    
      statusTag = status_xml.getElementsByTagName(Own3d._OWN3D_STATUS_TAG)[0]
      statusString = statusTag.childNodes[0].data

      if statusString == 'true':
	return True
    except (xml.parsers.expat.ExpatError, IndexError):
      return False
    return False

