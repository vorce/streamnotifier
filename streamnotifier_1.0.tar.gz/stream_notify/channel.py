__version__ = "0.1"
__date__ = "2010-11-10"
__author__ = "Joel Carlbark (joelcb@gmail.com)"

import threading, signal, httplib
import livestream, justin, ustream, own3d
import urllib2

class ChannelNotifier(threading.Thread):
  def __init__(self, stream, interval, notifiers=[]):
    threading.Thread.__init__(self, name='{0}:{1}'.format(stream.service_name, stream.channel))
    self._finished = threading.Event()
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    self._interval = interval
    self._wasLive = False
    self._notifiers = notifiers
    self.stream = stream
    
  def shutdown(self, timeout=None):
    self._finished.set()

  def run(self):
    while not self._finished.isSet():
      live = self.isLive()

      #for n in self._notifiers:
      #	n.notify(live)
      if(live and not self._wasLive):
	self._wasLive = True
	for n in self._notifiers:
	  n.notifyLive('')
      elif(not live and self._wasLive):
	self._wasLive = False
	for n in self._notifiers:
	  n.notifyDead('')
      #else:
	#n.notify(live)
      self._finished.wait(self._interval)
    
  def isLive(self):
    if self.stream == None:
      return False
    try:
      return self.stream.isLive()
    except (urllib2.URLError, httplib.HTTPException):
      return False
    
