import livestream, justin, ustream
import datetime
import smtplib

class Notifier:
  def __init__(self, streamservice):
    self.streamservice = streamservice
    self.inited = False

  def init(self):
    raise NotImplementedException("Subclasses are responsible for implementing this method")

  def notifyLive(self, more=''):
    raise NotImplementedException("Subclasses are responsible for implementing this method")
  
  def notifyDead(self, more=''):
    raise NotImplementedException("Subclasses are responsible for implementing this method")

class LogNotifier(Notifier):
  def init(self):
    self.name = 'Log notifier'
    self.filename = '{0}_{1}.log'.format(self.streamservice.service_name, self.streamservice.channel)
    self.inited = True

  def writeToLog(self, isLive):
    fp = open(self.filename, 'a')
    fp.write('{0}: {1}[{2}], isLive: {3}\n'.format(datetime.datetime.now(), self.streamservice.service_name, self.streamservice.channel, isLive))
    fp.close()

  def notifyLive(self, more=''):
    if(self.inited):
      self.writeToLog(True)

  def notifyDead(self, more=''):
    if(self.inited):
      self.writeToLog(False)

class GmailNotifier(Notifier):
  def init(self):
    self.name = 'Gmail notifier'
    self.gmailServer = 'smtp.gmail.com:587'
    self.inited = True

  def setCredentials(self, user, password):
    self.username = user
    self.password = password
    self.emailLiveHeader = 'From: {0}\r\nTo: {1}\r\nSubject: {2} {3} is up!\n\n'.format(self.username, self.username, self.streamservice.service_name, self.streamservice.channel)
    self.emailDeadHeader = 'From: {0}\r\nTo: {1}\r\nSubject: {2} {3} is down\n\n'.format(self.username, self.username, self.streamservice.service_name, self.streamservice.channel)

  def sendEmail(self, message):
    try:
      server = smtplib.SMTP(self.gmailServer)
      server.starttls()
      server.login(self.username, self.password)  
      server.sendmail(self.username, self.username, message)  
      server.quit()
    except smtplib.SMTPException:
      print('Unable to send email...')

  def notifyLive(self, more=''):
    self.sendEmail(self.emailLiveHeader + 'Gogo check {0}'.format(self.streamservice.url))

  def notifyDead(self, more=''):
    pass

