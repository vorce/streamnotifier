import streamservice
import json
import urllib2

# http://api.ustream.tv/[html|json|xml|php]/[subject]/[subjectUID|scope]/[command]/[otherparams]/?page=[n]&limit=[l]&key=[devkey]
class Ustream(streamservice.StreamService):
  _USTREAM_API_KEY = '0A1B9EA7B6D8925219D334D02288F685'
  _USTREAM_STREAM = 'channel'
  _USTREAM_RESULT = 'results'
  _USTREAM_STATUS = 'status'
  _stream_livestatus_prefix = 'http://api.ustream.tv/json/channel/'
  _stream_livestatus_suffix = '/getValueOf/status?key='
  _stream_prefix = 'http://ustream.tv/channel/'
  _service_name = 'Ustream'

  def __init__(self, channel):
    self.channel = channel
    self.status_url = '{0}{1}{2}{3}'.format(Ustream._stream_livestatus_prefix, channel, Ustream._stream_livestatus_suffix, Ustream._USTREAM_API_KEY)
    self.service_name = Ustream._service_name
    self.url = '{0}{1}'.format(Ustream._stream_prefix, channel)

  def isLive(self):
    channel_http = urllib2.urlopen(self.status_url)
    status_response = channel_http.readline()
    status_json = json.loads(status_response)
    try:
      liveStatus = status_json.get(Ustream._USTREAM_RESULT)
      if liveStatus == 'online':
	return True
      else:
	return False
    except (IndexError, AttributeError):
      return False
