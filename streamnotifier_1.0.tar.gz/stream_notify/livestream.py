import streamservice
import json
import urllib2
	
class Livestream(streamservice.StreamService):
  _LIVESTREAM_CHANNEL = 'channel'
  _LIVESTREAM_ISLIVE = 'isLive'
  _channel_livestatus_prefix = 'http://'
  _channel_livestatus_suffix = '.api.channel.livestream.com/2.0/livestatus.json'
  _channel_prefix = 'http://www.livestream.com/'
  _service_name = 'Livestream'
	
  def __init__(self, channel):
    self.channel = channel
    self.status_url = '{0}x{1}x{2}'.format(Livestream._channel_livestatus_prefix, channel.replace('_', '-'), Livestream._channel_livestatus_suffix)
    self.url = '{0}{1}'.format(Livestream._channel_prefix, channel)
    self.service_name = Livestream._service_name

  def isLive(self):
    channel_http = urllib2.urlopen(self.status_url)
    livestatus_response = channel_http.readline()
    livestatus_json = json.loads(livestatus_response)
    try:
      return livestatus_json.get(Livestream._LIVESTREAM_CHANNEL).get(Livestream._LIVESTREAM_ISLIVE)
    except (IndexError, AttributeError):
      return False
